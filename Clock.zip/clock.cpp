#include "Clock.h"
#include <iostream>
#include <iomanip>
#include <sstream>

using namespace std;

Clock::Clock(unsigned int h, unsigned int m, unsigned int s) {
    hours = h;
    minutes = m;
    seconds = s;
}

void Clock::addHour() {
    hours = (hours + 1) % 24;
}

void Clock::addMinute() {
    if (++minutes == 60) {
        minutes = 0;
        addHour();
    }
}

void Clock::addSecond() {
    if (++seconds == 60) {
        seconds = 0;
        addMinute();
    }
}

string Clock::get12HourFormat() const {
    unsigned int h = (hours % 12 == 0) ? 12 : hours % 12;
    string period = (hours < 12) ? "AM" : "PM";

    ostringstream oss;
    oss << setw(2) << setfill('0') << h << ":"
        << setw(2) << setfill('0') << minutes << ":"
        << setw(2) << setfill('0') << seconds << " " << period;

    return oss.str();
}

string Clock::get24HourFormat() const {
    ostringstream oss;
    oss << setw(2) << setfill('0') << hours << ":"
        << setw(2) << setfill('0') << minutes << ":"
        << setw(2) << setfill('0') << seconds;

    return oss.str();
}
