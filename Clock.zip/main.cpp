#include <iostream>
#include "Clock.h"

using namespace std;

// Function to display both clocks
void displayClocks(const Clock& clock) {
    cout << "**************************   **************************" << endl;
    cout << "*      12-HOUR CLOCK      *   *      24-HOUR CLOCK      *" << endl;
    cout << "*       " << clock.get12HourFormat() << "       *   *         " << clock.get24HourFormat() << "         *" << endl;
    cout << "**************************   **************************" << endl;
}

// Function to show the menu
void displayMenu() {
    cout << "\nMENU:\n";
    cout << "1 - Add One Hour\n";
    cout << "2 - Add One Minute\n";
    cout << "3 - Add One Second\n";
    cout << "4 - Exit\n";
    cout << "Enter your choice: ";
}

// Function to get a valid menu choice from the user
int getMenuChoice() {
    int choice;
    while (true) {
        cin >> choice;
        if (choice >= 1 && choice <= 4) {
            return choice;
        }
        cout << "Invalid choice. Please enter a number between 1 and 4: ";
    }
}

// Main function
int main() {
    unsigned int h, m, s;

    // Get initial time input from the user
    cout << "Enter initial time (HH MM SS): ";
    cin >> h >> m >> s;

    Clock clock(h, m, s);

    int choice;
    do {
        displayClocks(clock);
        displayMenu();
        choice = getMenuChoice();

        switch (choice) {
        case 1: clock.addHour(); break;
        case 2: clock.addMinute(); break;
        case 3: clock.addSecond(); break;
        }

    } while (choice != 4);

    cout << "Exiting program. Goodbye!\n";
    return 0;
}
