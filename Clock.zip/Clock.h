#ifndef CLOCK_H
#define CLOCK_H 
#include <string>

class Clock {
private:
    unsigned int hours;
    unsigned int minutes;
    unsigned int seconds;

public:
    Clock(unsigned int h = 0, unsigned int m = 0, unsigned int s = 0);

    void addHour();
    void addMinute();
    void addSecond();

    std::string get12HourFormat() const;
    std::string get24HourFormat() const;
};

#endif